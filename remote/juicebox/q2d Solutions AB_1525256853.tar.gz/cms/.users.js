({
  users: [{
    username: 'admin',
    tags: [],
    salt: 'bf62425eb119b87dccd58a4364b32bf2',
    hash: '50ad736fc3743e4af4e8e40d0a8b1b10f6ff0bc7be42e0a0d0201b137e41e22e',
    user_created_timestamp: 1523428793845
  }]
})