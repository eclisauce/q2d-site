({
	integration: {
		heading: 'Licensfri Integration',
		image: '',
		items: [
			{
				text: 'Remix är namnet på vårt koncept där vi använder licensfria produkter för att bygga webb- och mobila lösningar samt integration.'
			},
			{
				text: 'ReMix Integrationsmodul är ett kostnadseffektivt alternativ till integrationsplattformar från leverantörer som Microsoft och SAP. Dessa plattformar innehåller oftast en mängd funktioner som inte utnyttjas . De är dyra i inköp det tillkommer årliga kostnader och krävs specialutbildad personal alternativt specialiserade konsulter.'
			},
			{
				text: 'Remix Integration har varit i drift sedan 2012 i affärskritiska applikationer och används för att transportera data mellan affärssystem och webblösningar i exempelvis kundportaler.'
			},
			{
				text: 'ReMix Integration är driftsäker och uppgraderingsbar. Tekniskt bygger den .Net, C# ifrån Microsoft. Har man egen IT personal kan man själv driva lösningen vidare.'
			}
		]
	}
})