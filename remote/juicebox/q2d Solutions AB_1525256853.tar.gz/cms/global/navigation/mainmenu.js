({
	mainmenu: {
		items: [
			{
				label: 'Start',
				link: '/',
				new_window: false
			},
			{
				label: 'Produkter',
				link: '/product',
				new_window: false
			},
			{
				label: 'Utbildning',
				link: '/workshop',
				new_window: false
			},
			{
				label: 'Om oss',
				link: '/about',
				new_window: false
			}
		]
	}
})
